import './App.css';

function App() {
  return (
    <div className="container">
        <header> HEADER </header>
        <main>
            <article>
                <div id="sachBanChay"></div>
                <div id="doitac"></div>
                <div id="tinmoi"></div>
            </article>
            <aside>
                <div id="divCart">Gio Hang</div>
                <hr/>
                <div id="timSach">Tim Sach</div>
            </aside>
        </main>
        <footer>Họ và tên : Nguyễn Đức Sỹ</footer>
    </div>
  );
}

export default App;
