import React from 'react';
import '../HienGioHang.css';
export default class HienGioHang extends React.Component{
    constructor(props){
        super(props);
        this.state = {caption:"Sản phẩm đã chọn"};
    }

    render(){
        let kq = [];
        this.props.sachDaChon.forEach(sach => {
            kq.push(
                <div key={sach.id} className="motsach">
                    <img src={sach.urlHinh} align="left"/>
                    <p>{sach.tensach}</p>
                    <p>Giá: {sach.price} VNĐ</p>
                    <p><span >X</span></p>
                </div>
            );
        });
        const gh = 
            <div className="hiengiohang">
                <h2>{this.state.caption}</h2>
                {kq}
            </div>;
        return (gh);
    }
}