import React from 'react';
import '../ShowMotSach.css'
class MotSach extends React.Component{
    constructor(props){
        super();
        this.state={thich:false}
        console.log("Mot Sach Contructor");
        
    }
    thichSach = () => {
        this.setState({thich: true}); // thay đổi giá trị state thì sẽ chạy hàm should:36 bên dưới 
    }
    componentDidMount(){  // chạy 1 lần sau khi done render
        console.log("MotSach Didmount"); 
    }

    render(){
        console.log("MotSach Render");
        // console.log(this.props.sach);
        
        const kq = 
        <div className= {this.state.thich? 'MotSach thich' : 'MotSach'}>
        <h3>{this.props.sach.tenSach}</h3>
        <img src={this.props.sach.urlHinh}/>
            <p className="gia">{this.props.sach.price}</p>
            <p className="button">
                <button className="btnThich" type="button" onClick={this.thichSach}>Thích</button>
                <button className="btnChonMua" type="button" onClick={() => this.props.chonSach(this.props.sach.id)}>Chọn mua</button>
            </p>
            <p>{this.props.sach.mota}</p>
        </div>
        return (kq)
        
    }    
    shouldComponentUpdate(){
        console.log("MotSach shouldComponentUpdate");
        return true; //nếu là true thì tiếp tục render , ngược lại sẽ ngưng ko render nữa
    }
    componentDidUpdate(){
        console.log("MotSach componentDidUpdate"); // chạy sau khi Updatecomponent:36 và là cuối cùng
    }
}

export default MotSach;