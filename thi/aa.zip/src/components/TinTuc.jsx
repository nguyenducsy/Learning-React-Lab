import React from 'react';

function TinTuc(props) {
    return (
        <div>
            <h2>Trang TIn Tuc</h2>
        </div>
    );
}

export default TinTuc;