import React from 'react';
const DownLoad = () => {
    return (
        <h2>Đây là trang download, chỉ dành cho thành viên</h2>
    );
};
export default DownLoad;