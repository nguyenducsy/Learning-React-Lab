const LienHe = () => (
    <div> <h1>Đây là trang liên hệ</h1>  </div>
);
export default LienHe;
