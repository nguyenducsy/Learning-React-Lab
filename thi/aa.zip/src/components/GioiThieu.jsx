import React from 'react';

function GioiThieu(props) {
    return (
        <div>
            <h2>Trang Gioi Thieu</h2>
        </div>
    );
}

export default GioiThieu;