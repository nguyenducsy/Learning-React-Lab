export const THEM_SACH = "THEM_SACH";
export const CHINH_SACH = "SUA_SACH";
export const XOA_SACH = "XOA_SACH";

export const THEM_LOAISACH = "THEM_LOAISACH";
export const CHINH_LOAISACH = "SUA_LOAISACH";
export const XOA_LOAISACH = "XOA_LOAISACH";
export const TIENTE = "TIENTE";
export const DUA_SACH_VAO_STORE = "DUA_SACH_VAO_STORE";