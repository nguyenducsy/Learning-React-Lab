export const arrCate = [
    { id: 1, name: "Áo thun", sort: 1, show: 1 },
    { id: 2, name: "Giày", sort: 1, show: 1 },
    { id: 3, name: "Quần", sort: 1, show: 1 },
    { id: 4, name: "Sweater", sort: 1, show: 1 },
]