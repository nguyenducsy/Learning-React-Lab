 const arrSach = [
     { id: 1, tenSach: 'Bóng nước hồ gươm', price: 78000, urlHinh: "./images/lichsu/bong-nuoc-ho-guom.jpg" },
     { id: 2, tenSach: 'Có 500 năm như thế', price: 44000, urlHinh: "./images/lichsu/co-500-nam-nhu-the-2019.jpg" },
     { id: 3, tenSach: 'Cuộc nổi dậy của nhà Tây Sơn', price: 55000, urlHinh: "./images/lichsu/cuoc-noi-day-cua-nha-tay-son-bia-cung.jpg" },
     { id: 4, tenSach: 'Đại Việt sử ký ', price: 69000, urlHinh: "./images/lichsu/dai-viet-su-ky-tien-bien.jpg" },
     { id: 5, tenSach: 'La Sơn phu tử', price: 80000, urlHinh: "./images/lichsu/la-son-phu-tu.jpg" },
     { id: 6, tenSach: 'Lĩnh Nam Chích Quái', price: 89000, urlHinh: "./images/lichsu/linh-nam-chinh-quai.jpg" },
 ]
 export default arrSach;