
function App() {
  return (
   <p>Đây là app</p>
  );
}

export default App;
