import React from 'react';

function noidungchinh(props) {
    return (
        <div>
<img src="https://i.pinimg.com/564x/9c/07/19/9c0719739aebfb397fcc45a9815dbbec.jpg" alt=""></img>
        </div>
    );
}

export default noidungchinh;