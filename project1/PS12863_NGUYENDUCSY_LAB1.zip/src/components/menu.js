import React from 'react';

function menu(props) {
    return (
        <div>
            <ul>
                <li><a href="#">Trang chu</a> </li>
                <li><a href="#">Tin tuc</a> </li>
                <li><a href="#">Lien he</a> </li>
            </ul>
        </div>
    );
}

export default menu;