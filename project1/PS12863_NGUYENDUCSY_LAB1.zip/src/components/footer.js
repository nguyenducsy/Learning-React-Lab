import React from 'react';

function footer(props) {
    return (
        <>
        <img src="./footer.JPG" alt=""></img>
        </>
    );
}


export default footer;