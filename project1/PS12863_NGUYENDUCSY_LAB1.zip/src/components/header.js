import React from 'react';

function header(props) {
    return ( <div className = "logo" >
        <img src="./1.jpg" alt=""></img>
            </div>
    );
}

export default header;